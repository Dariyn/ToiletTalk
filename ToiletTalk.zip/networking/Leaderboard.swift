//
//  Leaderboard.swift
//  networking
//
//  Created by Darren Choy on 5/5/2022.
//

struct Leaderboard : Decodable {
    let location_id: String
    let message_counter: Int
}

struct Leaderboards : Decodable {
    let leaderboard : [Leaderboard]
}
