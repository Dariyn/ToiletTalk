//
//  LeaderboardTableViewCell.swift
//  networking
//
//  Created by Darren Choy on 5/5/2022.
//

import UIKit

class LeaderboardTableViewCell: UITableViewCell {

    let profileImageView = UIImageView()
    let location_idImageView = UIImageView()
    let descriptionLabel = UILabel()
    let location_idLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        setupViews()
        setupConstraints()
    }
    
    func setupViews() {
//        profileImageView.image = UIImage(systemName: "1.circle.fill")
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        profileImageView.tintColor = .black

        contentView.addSubview(profileImageView)
        
        
        
        descriptionLabel.font = UIFont.systemFont(ofSize: 15)
        descriptionLabel.numberOfLines = 0
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(descriptionLabel)
        
        location_idLabel.font = UIFont.systemFont(ofSize: 15)
        location_idLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(location_idLabel)
        
    }
    
    func setupConstraints() {
        let profileImageDim: CGFloat = 30
        let topPadding: CGFloat = 20.0
        let sidePadding: CGFloat = 20.0

        // profileImageView - Person Icon
        NSLayoutConstraint.activate([
            profileImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            profileImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: sidePadding),
            profileImageView.heightAnchor.constraint(equalToConstant: profileImageDim),
            profileImageView.widthAnchor.constraint(equalToConstant: profileImageDim)
        ])

        

        // descriptionLabel
        NSLayoutConstraint.activate([
            descriptionLabel.heightAnchor.constraint(equalToConstant: 50),
            descriptionLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant:  topPadding/3),
//            descriptionLabel.leadingAnchor.constraint(equalTo: profileImageView.trailingAnchor, constant: sidePadding),
//            descriptionLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            descriptionLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant:-sidePadding),
            descriptionLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
            
        ])


        // location_idLabel
        NSLayoutConstraint.activate([
            location_idLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: topPadding/3),
            location_idLabel.heightAnchor.constraint(equalToConstant: 50),

            location_idLabel.leadingAnchor.constraint(equalTo: profileImageView.trailingAnchor, constant: sidePadding+20),
//            location_idLabel.trailingAnchor.constraint(equalTo: descriptionLabel.leadingAnchor, constant: -20),
//            location_idLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor,constant: -topPadding/3),
            location_idLabel.centerYAnchor.constraint(equalTo: descriptionLabel.centerYAnchor)
        ])

    }
    
    func configure(with leaderObject: Leaderboard) {
        location_idLabel.text = leaderObject.location_id
        descriptionLabel.text = String(leaderObject.message_counter)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
