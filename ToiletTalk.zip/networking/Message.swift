//
//  Message.swift
//  networking
//
//  Created by Darren Choy on 4/29/22.
//


struct Message : Decodable {
    let message_id: Int
    let location_id: String
    let description: String
}

struct Messages : Decodable {
    let messages : [Message]
}

