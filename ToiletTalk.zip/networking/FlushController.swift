//
//  FlushController.swift
//  networking
//
//  Created by Darren Choy on 6/5/2022.
//

import UIKit

class FlushController: UIViewController {
    var titleLabel = UILabel()
    var icon = UIImageView()
    var login = UIButton()
    var location = UITextField()
    var password = UITextField()
    var backgroundbut = UIButton()
    
  

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        icon.image = UIImage(named:"whitelogo")
        icon.contentMode = .scaleAspectFill
        icon.clipsToBounds = true
        icon.layer.cornerRadius = 5
        icon.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(icon)
        
    

        
        login.backgroundColor = .black
        login.setTitle("   Flush!   ", for: .normal)
        login.setTitleColor(.white, for: .normal)
        login.titleLabel?.font = .systemFont(ofSize: 20)
        login.translatesAutoresizingMaskIntoConstraints = false
        login.addTarget(self, action: #selector(loginTapped), for: .touchUpInside)
//        login.layer.borderColor = UIColor.systemBlue.cgColor
        login.layer.borderWidth = 5
        login.layer.cornerRadius = 10
        
       

        view.addSubview(login)
        backgroundbut.backgroundColor = .systemGray
//        backgroundbut.setTitle("   Login!   ", for: .normal)
//        backgroundbut.setTitleColor(.black, for: .normal)
        backgroundbut.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(backgroundbut)


       setupConstraints()
    }
    func setupConstraints()  {
        NSLayoutConstraint.activate([
            icon.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            icon.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            icon.widthAnchor.constraint(equalToConstant: 250),
            icon.heightAnchor.constraint(equalToConstant: 250)
        ])
        

        NSLayoutConstraint.activate([
            login.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 50),
            login.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            login.widthAnchor.constraint(equalTo: icon.widthAnchor),
            login.heightAnchor.constraint(equalToConstant: 100)
        ])
        NSLayoutConstraint.activate([
            backgroundbut.bottomAnchor.constraint(equalTo: view.bottomAnchor),
//            backgroundbut.topAnchor.constraint(equalTo: leaderboardTableView.bottomAnchor, constant: 50),
            backgroundbut.heightAnchor.constraint(equalToConstant: 100),
            backgroundbut.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            backgroundbut.widthAnchor.constraint(equalTo: view.widthAnchor)


        ])
        
    }
    @objc func loginTapped() {
//       print ("flushed!")
        let tabBarVC = UITabBarController()
        let vc1 = UINavigationController(rootViewController:  LoginController())
        vc1.tabBarItem.image = UIImage(systemName: "message.fill")
        tabBarVC.tabBar.backgroundColor = .black
        tabBarVC.tabBar.tintColor = .black
        tabBarVC.tabBar.unselectedItemTintColor = .white

       
        tabBarVC.setViewControllers([vc1], animated: false)
        tabBarVC.modalPresentationStyle = .fullScreen
        
        self.present(tabBarVC, animated: true)
    
}
}
