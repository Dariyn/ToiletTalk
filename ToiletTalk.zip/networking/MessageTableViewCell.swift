//
//  MessageTableViewCell.swift
//  networking
//
//  Created by Darren Choy on 4/29/22.
//

import UIKit

class MessageTableViewCell: UITableViewCell {

    let profileImageView = UIImageView()
    let location_idImageView = UIImageView()
    let descriptionLabel = UILabel()
    let location_idLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        setupViews()
        setupConstraints()
    }
    
    func setupViews() {
        profileImageView.image = UIImage(systemName: "person.crop.circle")
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        profileImageView.tintColor = .black

        contentView.addSubview(profileImageView)
        
        
        
        descriptionLabel.font = UIFont.systemFont(ofSize: 20)
        descriptionLabel.numberOfLines = 0
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(descriptionLabel)
        
        location_idLabel.font = UIFont.systemFont(ofSize: 10, weight: .heavy)
        location_idLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(location_idLabel)
        
    }
    
    func setupConstraints() {
        let profileImageDim: CGFloat = 30
//        let topPadding: CGFloat = 20.0
        let sidePadding: CGFloat = 20.0

        // profileImageView - Person Icon
        NSLayoutConstraint.activate([
            profileImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            profileImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: sidePadding),
            profileImageView.heightAnchor.constraint(equalToConstant: profileImageDim),
            profileImageView.widthAnchor.constraint(equalToConstant: profileImageDim)
        ])

        

        // descriptionLabel
        NSLayoutConstraint.activate([
            descriptionLabel.heightAnchor.constraint(equalToConstant: 30),
            descriptionLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 15),
            descriptionLabel.leadingAnchor.constraint(equalTo: profileImageView.trailingAnchor, constant: sidePadding),
            descriptionLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant:-sidePadding)
        ])


        // location_idLabel
        NSLayoutConstraint.activate([
            location_idLabel.heightAnchor.constraint(equalToConstant: 30),
            location_idLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 5),
            location_idLabel.leadingAnchor.constraint(equalTo: descriptionLabel.leadingAnchor),
            location_idLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -sidePadding),
            location_idLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor,constant: -5)
        ])

    }
    
    func configure(with messageObject: Message) {
        location_idLabel.text = messageObject.location_id
        descriptionLabel.text = messageObject.description
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
