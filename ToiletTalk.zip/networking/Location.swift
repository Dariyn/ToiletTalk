//
//  Location.swift
//  networking
//
//  Created by Darren Choy on 5/5/2022.
//

struct LocationRequest : Encodable {
    let location : String
    let password : Int
    
}

struct LocationResponse : Decodable {
    let valid: Bool
}


