//
//  LoginController.swift
//  networking
//
//  Created by Darren Choy on 5/5/2022.
//

import UIKit

class LoginController: UIViewController {
    var titleLabel = UILabel()
    var icon = UIImageView()
    var login = UIButton()
    var location = UITextField()
    var password = UITextField()
  

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .black
        icon.image = UIImage(named:"icon")
        icon.contentMode = .scaleAspectFill
        icon.clipsToBounds = true
        icon.layer.cornerRadius = 5
        icon.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(icon)
        
        let labelColor = UIColor.white

        titleLabel.text = "ToiletTalk"
        titleLabel.textColor = labelColor
        titleLabel.font = .systemFont(ofSize: 50, weight:.bold)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)
        
        location.placeholder = "  Enter location"
        location.backgroundColor = labelColor
        location.textColor = .black
        location.translatesAutoresizingMaskIntoConstraints = false
    
        

        view.addSubview(location)
        
        password.placeholder = "  Enter password"
        password.backgroundColor = .white
        password.textColor = .black
        password.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(password)
    

        
        login.backgroundColor = .white
        login.setTitle("   Login!   ", for: .normal)
        login.setTitleColor(.black, for: .normal)
        login.translatesAutoresizingMaskIntoConstraints = false
        login.addTarget(self, action: #selector(loginTapped), for: .touchUpInside)

        view.addSubview(login)
        


       setupConstraints()
    }
    func setupConstraints()  {
        NSLayoutConstraint.activate([
            icon.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            icon.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            icon.widthAnchor.constraint(equalToConstant: 250),
            icon.heightAnchor.constraint(equalToConstant: 250)
        ])
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: icon.centerXAnchor)
        ])
        NSLayoutConstraint.activate([
            location.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 50),
            location.centerXAnchor.constraint(equalTo: titleLabel.centerXAnchor),
            location.widthAnchor.constraint(equalTo: icon.widthAnchor),
            location.heightAnchor.constraint(equalToConstant: 50)
            
        ])
        NSLayoutConstraint.activate([
            password.topAnchor.constraint(equalTo: location.bottomAnchor, constant: 20),
            password.centerXAnchor.constraint(equalTo: location.centerXAnchor),
            password.widthAnchor.constraint(equalTo: icon.widthAnchor),
            password.heightAnchor.constraint(equalToConstant: 50)
        ])

        NSLayoutConstraint.activate([
            login.topAnchor.constraint(equalTo: password.bottomAnchor, constant: 20),
            login.centerXAnchor.constraint(equalTo: password.centerXAnchor),
            login.widthAnchor.constraint(equalTo: icon.widthAnchor),
            login.heightAnchor.constraint(equalToConstant: 50)
        ])
        
    }
    
    @objc func loginTapped() {
        var passValid = LocationResponse(valid: false)
        if let locationString = location.text, let passwordInt = Int(password.text ?? ""){
            NetworkManager.checkvalid(location: locationString, password: passwordInt, completion: { result in
                passValid = LocationResponse(valid: result.valid)
                if passValid.valid == true{
                    self.location.text = ""
                    self.password.text = ""
//                    self.navigationController?.pushViewController(ViewController(), animated: true)
                    let tabBarVC = UITabBarController()
                    let vc1 = UINavigationController(rootViewController:  ViewController())
                    let vc2 = UINavigationController(rootViewController:  LeaderboardController())
                    let vc3 = UINavigationController(rootViewController: FlushController())
                    vc1.tabBarItem.image = UIImage(systemName: "message.fill")
                    vc2.tabBarItem.image = UIImage(systemName: "chart.bar.xaxis")
                    vc3.tabBarItem.image = UIImage(systemName: "figure.walk")
                    tabBarVC.tabBar.backgroundColor = .systemGray
                    tabBarVC.tabBar.tintColor = .black
                    tabBarVC.tabBar.unselectedItemTintColor = .white

                    vc1.title  = "Message"
                    vc2.title = "Leaderboard"
                    vc3.title = "Flush!"
                    tabBarVC.setViewControllers([vc1, vc2, vc3], animated: false)
                    tabBarVC.modalPresentationStyle = .fullScreen
                    
                    self.present(tabBarVC, animated: true)
                }
                else {self.showAlert()}
                
            })
            
          
            
            }
        
          
}
    @IBAction func showAlert() {
        let alertController = UIAlertController(title: "Wrong password...", message:
            "Try again!", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))

        self.present(alertController, animated: true, completion: nil)
    }

    }

