//
//  NetworkManager.swift
//  networking
//
//  Created by Darren Choy on 4/29/22.
//
import Alamofire
import Foundation

class NetworkManager {
    
   
    static let host = "http://34.85.193.31"

    static func checkvalid( location: String, password: Int, completion: @escaping (LocationResponse) -> Void) {
        let endpoint = "\(host)/api/locations/"
        let params = LocationRequest(location: location, password: password)
        AF.request(endpoint, method: .post, parameters: params, encoder: JSONParameterEncoder.default).validate().responseData { response in
            switch (response.result) {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(LocationResponse.self, from: data) {
                    print ("done")
                    completion(userResponse)
                } else {
                    print ("Failed to decode password")
                }
                print(data)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getLeaderboard(completion: @escaping (Leaderboards) -> Void) {
        let endpoint = "\(host)/api/leaderboard/"
        AF.request(endpoint, method: .get).validate().responseData { response in
            switch (response.result) {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(Leaderboards.self, from: data) {
                    completion(userResponse)
                } else {
                    print ("Failed to decode getLeaderboardPosts")
                }
                print(data)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    static func getAllPosts(completion: @escaping (Messages) -> Void) {
        let endpoint = "\(host)/api/messages/"
        AF.request(endpoint, method: .get).validate().responseData { response in
            switch (response.result) {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(Messages.self, from: data) {
                    completion(userResponse)
                } else {
                    print ("Failed to decode getAllPosts")
                }
                print(data)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    
  
    static func createPost( description: String, location_id: String, completion: @escaping (Message) -> Void) {
        let endpoint = "\(host)/api/messages/"
        let params : [String: String] = [  "description" : description, "location_id" : location_id]
        AF.request(endpoint, method: .post, parameters: params, encoder: JSONParameterEncoder.default).validate().responseData { response in
            switch (response.result) {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(Message.self, from: data) {
                    completion(userResponse)
                } else {
                    print ("Failed to decode createPost")
                }
                print(data)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
 
    
    static func deletePost(message_id : Int, description : String, location_id: String, completion: @escaping (Message) -> Void) {
        let endpoint = "\(host)/api/messages/\(message_id)/"
        
        AF.request(endpoint, method: .delete).validate().responseData { response in
            switch (response.result) {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let location_idResponse = try? jsonDecoder.decode(Message.self, from: data) {
                    completion(location_idResponse)
                } else {
                    print ("Failed to decode deletePost")
                }
                print(data)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
  

}
