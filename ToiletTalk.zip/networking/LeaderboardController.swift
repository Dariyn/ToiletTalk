//
//  LeaderboardController.swift
//  networking
//
//  Created by Darren Choy on 5/5/2022.

import UIKit

class LeaderboardController: UIViewController, UITableViewDelegate {

    // MARK: UI Elements
    let leaderTableView = UITableView()
    let filterMessageButton = UIBarButtonItem()
    let addMessageButton = UIBarButtonItem()
    let leaderboardReuseIdentifier = "leaderboardReuseIdentifier"
    let rankLabel = UILabel()
    let locLabel = UILabel()
    let message_count = UILabel()
    
    let refreshControl = UIRefreshControl()
    
    // Learn how to setup UIAlertControllers here https://learnappmaking.com/uialertcontroller-alerts-swift-how-to/
    let createAlert = UIAlertController(title: "Add new message", message: nil, preferredStyle: .alert)
    let filterAlert = UIAlertController(title: "Filter location_id's messages", message: nil, preferredStyle: .alert)
    let updateAlert = UIAlertController(title: "Update your message", message: nil, preferredStyle: .alert)
    
    var leaderboardData: [Leaderboard] = []
    var shownLeaderboardData: [Leaderboard] = []
    var backgroundbut = UIButton()
    
    var currentIndexPathToUpdate: IndexPath? // We use this for updating and deleting
  

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Leader Board"
        view.backgroundColor = .white
        setupViews()
        setupConstraints()
        refreshData()

    }
    
   
    func sortleaderboardData() {
        leaderboardData.sort { (leftMessage, rightMessage) -> Bool in
            return leftMessage.message_counter > rightMessage.message_counter
        }
    }

    

    
    func setupViews() {
        
        
        
        leaderTableView.translatesAutoresizingMaskIntoConstraints = false
        leaderTableView.delegate = self
        leaderTableView.dataSource = self
        leaderTableView.register(LeaderboardTableViewCell.self, forCellReuseIdentifier: leaderboardReuseIdentifier)
        leaderTableView.backgroundColor = .white

        view.addSubview(leaderTableView)

        backgroundbut.backgroundColor = .systemGray
//        backgroundbut.setTitle("   Login!   ", for: .normal)
//        backgroundbut.setTitleColor(.black, for: .normal)
        backgroundbut.translatesAutoresizingMaskIntoConstraints = false
//        backgroundbut.addTarget(self, action: #selector(#present), for: .touchUpInside)

        view.addSubview(backgroundbut)
        
        rankLabel.text = "Rank"
        rankLabel.textColor = .black
        rankLabel.font = .systemFont(ofSize: 20, weight:.bold)
        rankLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(rankLabel)
        
        locLabel.text = "location"
        locLabel.textColor = .black
        locLabel.font = .systemFont(ofSize: 20, weight:.bold)
        locLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(locLabel)
        
        message_count.text = "message count"
        message_count.textColor = .black
        message_count.font = .systemFont(ofSize: 20, weight:.bold)
        message_count.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(message_count)
        
        if #available(iOS 10.0, *) {
            leaderTableView.refreshControl = refreshControl
        } else {
            leaderTableView.addSubview(refreshControl)
        }
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        
        
    
        }
    func setupConstraints() {
        NSLayoutConstraint.activate([
            rankLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant: 20),
//            backgroundbut.topAnchor.constraint(equalTo: leaderboardTableView.bottomAnchor, constant: 50),
            rankLabel.heightAnchor.constraint(equalToConstant: 20),
            rankLabel.widthAnchor.constraint(equalToConstant: 50),
            rankLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10)


        ])
        NSLayoutConstraint.activate([
            locLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant: 20),
//            backgroundbut.topAnchor.constraint(equalTo: leaderboardTableView.bottomAnchor, constant: 50),
            locLabel.heightAnchor.constraint(equalToConstant: 20),
            locLabel.widthAnchor.constraint(equalToConstant: 100),
            locLabel.leadingAnchor.constraint(equalTo: rankLabel.trailingAnchor, constant: 30)


        ])
        NSLayoutConstraint.activate([
            message_count.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant: 20),
//            backgroundbut.topAnchor.constraint(equalTo: leaderboardTableView.bottomAnchor, constant: 50),
            message_count.heightAnchor.constraint(equalToConstant: 20),
            message_count.widthAnchor.constraint(equalToConstant: 150),
            message_count.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10)


        ])
        NSLayoutConstraint.activate([
            leaderTableView.topAnchor.constraint(equalTo: rankLabel.bottomAnchor, constant: 10),
            leaderTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            leaderTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            leaderTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            
        ])
        NSLayoutConstraint.activate([
            backgroundbut.bottomAnchor.constraint(equalTo: view.bottomAnchor),
//            backgroundbut.topAnchor.constraint(equalTo: leaderboardTableView.bottomAnchor, constant: 50),
            backgroundbut.heightAnchor.constraint(equalToConstant: 100),
            backgroundbut.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            backgroundbut.widthAnchor.constraint(equalTo: view.widthAnchor)


        ])
        
    }

   
        
    @objc func refreshData() {
       
        NetworkManager.getLeaderboard { scores in
            self.leaderboardData = scores.leaderboard
            self.sortleaderboardData()
            self.sortleaderboardData()

            self.shownLeaderboardData = self.leaderboardData
            self.leaderTableView.reloadData()
            self.refreshControl.endRefreshing()
        }
    }
    
    @objc func prepareFilteringAction() {
        if filterMessageButton.title == "Filter" {
            present(filterAlert, animated: true)
        } else {
            filterMessageButton.title = "Filter"
            shownLeaderboardData = leaderboardData
        }
    }
    
    @objc func presentCreateAlert() {
        present(createAlert, animated: true)
    }
   
    
}




extension LeaderboardController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shownLeaderboardData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: leaderboardReuseIdentifier, for: indexPath) as! LeaderboardTableViewCell
        let leaderObject = shownLeaderboardData[indexPath.row]
        cell.profileImageView.image = UIImage(systemName: "\(indexPath.row+1).circle.fill")

        cell.configure(with: leaderObject)
        return cell
    }
}

