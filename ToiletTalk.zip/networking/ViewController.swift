//
//  ViewController.swift
//  networking
//
//  Created by Darren Choy on 4/29/22.
//

import UIKit

class ViewController: UIViewController {

    // MARK: UI Elements
    let messageTableView = UITableView()
    let filterMessageButton = UIBarButtonItem()
    let addMessageButton = UIBarButtonItem()
    let messageReuseIdentifier = "messageReuseIdentifier"
    
    let refreshControl = UIRefreshControl()
    
    // Learn how to setup UIAlertControllers here https://learnappmaking.com/uialertcontroller-alerts-swift-how-to/
    let createAlert = UIAlertController(title: "Add new message", message: nil, preferredStyle: .alert)
    let filterAlert = UIAlertController(title: "Filter location_id's messages", message: nil, preferredStyle: .alert)
    let updateAlert = UIAlertController(title: "Update your message", message: nil, preferredStyle: .alert)
    
    var messageData: [Message] = []
    var shownMessageData: [Message] = []
    var backgroundbut = UIButton()
    
    var currentIndexPathToUpdate: IndexPath? // We use this for updating and deleting
  

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Message Board"
        view.backgroundColor = .white
        createDummyData()
        setupViews()
        setupConstraints()
        refreshData()

    }
    
   
    func sortMessageData() {
        messageData.sort { (leftMessage, rightMessage) -> Bool in
            return leftMessage.message_id > rightMessage.message_id
        }
    }
    
    func createDummyData() {
        
        let post1 = Message(message_id: 0,  location_id: "Justin", description: "I'm hungry")
        let post2 = Message(message_id: 1, location_id: "Justin", description: "I'm world" )
        let post3 = Message(message_id: 2,  location_id: "Noah", description: "That's not what I meant")
        let post4 = Message(message_id: 3,  location_id: "Noah", description: String(repeating: "spam", count: 100))
        let post5 = Message(message_id: 4, location_id: "Justin",description: "Sorry")

        messageData = [post1, post2, post3, post4, post5]
        sortMessageData()
        shownMessageData = messageData
    }
    

    
    func setupViews() {
        
        
        
        messageTableView.translatesAutoresizingMaskIntoConstraints = false
        messageTableView.delegate = self
        messageTableView.dataSource = self
        messageTableView.register(MessageTableViewCell.self, forCellReuseIdentifier: messageReuseIdentifier)
        messageTableView.backgroundColor = .white

        view.addSubview(messageTableView)
        
        backgroundbut.backgroundColor = .systemGray
//        backgroundbut.setTitle("   Login!   ", for: .normal)
//        backgroundbut.setTitleColor(.black, for: .normal)
        backgroundbut.translatesAutoresizingMaskIntoConstraints = false
//        backgroundbut.addTarget(self, action: #selector(#present), for: .touchUpInside)

        view.addSubview(backgroundbut)
        
        if #available(iOS 10.0, *) {
            messageTableView.refreshControl = refreshControl
        } else {
            messageTableView.addSubview(refreshControl)
        }
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        
        
        
        addMessageButton.image = UIImage(systemName: "plus.message")
        addMessageButton.target = self
        addMessageButton.tintColor = .black

        addMessageButton.action = #selector(presentCreateAlert)
//        #selector(presentViewController)
        navigationItem.rightBarButtonItem = addMessageButton
        self.navigationController?.navigationBar.barTintColor  = .systemGray
        createAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        createAlert.addTextField(configurationHandler: { textField in
            
            textField.placeholder = "Share your toilet thoughs..."
    
      
            self.createAlert.addAction(UIAlertAction(title: "Create", style: .default, handler: { action in
            if let textFields = self.createAlert.textFields,
               let description = textFields[0].text?.trimmingCharacters(in: .whitespacesAndNewlines),
//               let location_id = textFields[1].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               description != "" {
//               location_id != ""
                NetworkManager.createPost(description: description, location_id: "Duffield First Floor") { message in
                    let newpost = Message(message_id: message.message_id, location_id: message.location_id,  description: message.description)
                    self.messageData.append(newpost)
                    self.shownMessageData = self.messageData
                    self.messageTableView.reloadData()
                    self.refreshControl.endRefreshing()
                    
                }
                print(" \(description)")
//                 \(location_id)
            }
        }))
        
            self.updateAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.updateAlert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Update the message description here..."
        })
           
//            self.updateAlert.addAction(UIAlertAction(title: "Update", style: .default, handler: { action in
//          
            self.updateAlert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { action in
            if let textFields = self.updateAlert.textFields,
               let description = textFields[0].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               let indexPath = self.currentIndexPathToUpdate {
                
                let message_id = self.shownMessageData[indexPath.row].message_id

                NetworkManager.deletePost(message_id : message_id, description : description, location_id: "Duffield First Floor"){ message in
                    let deletedpost = Message(message_id: message.message_id, location_id: message.location_id,  description: message.description)
                    self.messageData = self.messageData.filter{$0.message_id != deletedpost.message_id}
                    self.shownMessageData = self.messageData
                    self.messageTableView.reloadData()
                    self.refreshControl.endRefreshing()
                    
                }
                print("\(indexPath) \(description)")
            }
        }))
    }
        )}
    func setupConstraints() {
       
        NSLayoutConstraint.activate([
            messageTableView.topAnchor.constraint(equalTo: view.topAnchor),
            messageTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            messageTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            messageTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            
        ])
        NSLayoutConstraint.activate([
            backgroundbut.bottomAnchor.constraint(equalTo: view.bottomAnchor),
//            backgroundbut.topAnchor.constraint(equalTo: messageTableView.bottomAnchor, constant: 50),
            backgroundbut.heightAnchor.constraint(equalToConstant: 100),
            backgroundbut.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            backgroundbut.widthAnchor.constraint(equalTo: view.widthAnchor)


        ])
    }
    
        
    @objc func refreshData() {
       
        NetworkManager.getAllPosts { messages in
            self.messageData = messages.messages
            self.shownMessageData = self.messageData
            self.messageTableView.reloadData()
            self.refreshControl.endRefreshing()
        }
    }
    
    @objc func prepareFilteringAction() {
        if filterMessageButton.title == "Filter" {
            present(filterAlert, animated: true)
        } else {
            filterMessageButton.title = "Filter"
            shownMessageData = messageData
        }
    }
    
    @objc func presentCreateAlert() {
        present(createAlert, animated: true)
    }
    
    
}


extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        updateAlert.textFields?[0].text = shownMessageData[indexPath.row].description
        currentIndexPathToUpdate = indexPath
        present(updateAlert, animated: true)
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shownMessageData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: messageReuseIdentifier, for: indexPath) as! MessageTableViewCell
        let messageObject = shownMessageData[indexPath.row]
        cell.configure(with: messageObject)
        return cell
    }
}

